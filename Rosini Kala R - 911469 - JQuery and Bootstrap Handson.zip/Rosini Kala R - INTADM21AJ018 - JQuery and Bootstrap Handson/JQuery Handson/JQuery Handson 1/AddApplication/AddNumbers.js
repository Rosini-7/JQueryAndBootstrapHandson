function add_two_number(){
    $("#res").val("");
            var a=$("#num1").val();
            var b=$("#num2").val();
            if(a=="" || b==""){
                $("#failure").html("<font color='red'>Pls.Enter the Values</font>")
            }
            else{
            var res=parseInt(a)+parseInt(b);
           
            $("#res").val(res);
            $("#failure").html("<font color='green'>"+res+"</font>");
            }
}