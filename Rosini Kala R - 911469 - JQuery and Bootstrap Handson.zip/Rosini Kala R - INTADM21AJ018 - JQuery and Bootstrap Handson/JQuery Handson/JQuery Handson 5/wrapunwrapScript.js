$(document).ready(() => {
    var pTags = $("p");
    $("#WrapUnwrapVar").click(function () {
      if (pTags.parent().is("div")) {
        pTags.unwrap();
      } else {
        pTags.wrap("<div>");
      }
    });
  });