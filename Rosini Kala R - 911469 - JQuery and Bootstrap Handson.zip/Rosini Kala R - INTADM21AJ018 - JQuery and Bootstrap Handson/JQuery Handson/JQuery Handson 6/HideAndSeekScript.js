$(document).ready(() => {
  $("#d1").click(function () {
    $(this).css("background-color", "yellow");
  });
  $("#d2").click(function () {
    $(this).css("background-color", "green");
  });
  $("#d3").click(function () {
    $(this).css("background-color", "red");
  });
  $("#d4").click(function () {
    $(this).css("background-color", "pink");
  });

  var div;
  $("#atchbtn").click(function () {
    if (div) {
      div.appendTo("body");
      $("div").css("display","block");
      $("div").css("margin","0px 0px 2px 0px");
      div = null;
    } else {
      div = $("div").detach();
    }
  });
});